# ffruit-mvc

FFruit - MVC - OOP - PHP

#Usage
