<?php


namespace App\App\Models;


use App\App\Models\BaseModel;


class Order extends BaseModel
{

    function __construct()
    {
        parent::__construct();
    }
}
