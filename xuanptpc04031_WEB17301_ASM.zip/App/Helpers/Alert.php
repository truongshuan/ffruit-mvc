<?php

namespace App\App\Helpers;

class Alert
{
    private $_success;
    private $_error;

    public function alertSuccess($title, $message): void
    {
    }
    public function alertError($title, $message): void{

    }
}