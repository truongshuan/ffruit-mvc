<?php


namespace App\Config;

class App
{

    function __construct()
    {
        echo 'Day la routes';
    }
    public function productDetail()
    {
        echo 'day la chi tiet san pham';
    }
    public function categories()
    {
        echo 'day la loai san pham';
    }
    public function tagsCategory()
    {
    }
}
